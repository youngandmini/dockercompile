package com.example.dockercompile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DockercompileApplication {

	public static void main(String[] args) {
		SpringApplication.run(DockercompileApplication.class, args);
	}

}
